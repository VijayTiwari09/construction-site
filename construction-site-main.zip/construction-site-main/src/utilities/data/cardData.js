import child from "../../images/Rectangle 4.png";
import child1 from "../../images/Rectangle 4 (3).png";
import child2 from "../../images/Rectangle 4 (5).png";
import child4 from "../../images/Rectangle 4 (7).png";
import child3 from "../../images/Rectangle 4 (8).png";
import child5 from "../../images/Rectangle 4 (4).png";

export const pressRelease = [
  {
    h2: "Stone Laying Ceremony Marks Commencement of 132 km Amarpur-Dhungesanghu",
    p: "In this article, I won’t talk about the general concepts of typography, which can be used both in print...",
    image: child,
    li: "Jun 27, 2020 · 6 min ago",
  },
  {
    h2: "Cosmic Electrical Limited Successfully Completes and Charges 13kV Power...",
    p: "In this article, I won’t talk about the general concepts of typography, which can be used both in print...",
    image: child1,
    li: "Jun 27, 2020 · 6 min ago",
  },
  {
    h2: "CEL Employees Embrace Camaraderie and Team Spirit at Annual Office Picnic",
    p: "In this article, I won’t talk about the general concepts of typography, which can be used both in print...",
    image: child2,
    li: "Jun 27, 2020 · 6 min ago",
  },
  {
    h2: "CEL Employees Embrace Camaraderie and Team Spirit at Annual Office Picnic",
    p: "In this article, I won’t talk about the general concepts of typography, which can be used both in print...",
    image: child3,
    li: "Jun 27, 2020 · 6 min ago",
  },
  {
    h2: "Cosmic Electrical Limited Successfully Completes and Charges 132kV Power...",
    p: "In this article, I won’t talk about the general concepts of typography, which can be used both in print...",
    image: child4,
    li: "Jun 27, 2020 · 6 min ago",
  },
  {
    h2: "CEL Employees Embrace Camaraderie and Team Spirit at Annual Office Picnic",
    p: "In this article, I won’t talk about the general concepts of typography, which can be used both in print...",
    image: child5,
    li: "Jun 27, 2020 · 6 min ago",
  },
  {
    h2: "CEL Employees Embrace Camaraderie and Team Spirit at Annual Office Picnic",
    p: "In this article, I won’t talk about the general concepts of typography, which can be used both in print...",
    image: child5,
    li: "Jun 27, 2020 · 6 min ago",
  },
  {
    h2: "CEL Employees Embrace Camaraderie and Team Spirit at Annual Office Picnic",
    p: "In this article, I won’t talk about the general concepts of typography, which can be used both in print...",
    image: child2,
    li: "Jun 27, 2020 · 6 min ago",
  },
  {
    h2: "CEL Employees Embrace Camaraderie and Team Spirit at Annual Office Picnic",
    p: "In this article, I won’t talk about the general concepts of typography, which can be used both in print...",
    image: child5,
    li: "Jun 27, 2020 · 6 min ago",
  },
];

export const Hometestomonials = [
  {
    name: "Darrell Steward",
    companyName: "South market business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
  {
    name: "Courtney Henry",
    companyName: "South market street plaza",
    description:
      "Our project is was completed on time and within budget, and qualify of craftmanship exceeded our expections. What truly set [Company Name] apart",
  },
  {
    name: "Darrell Steward",
    companyName: "business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
];

export const testomonials = [
  {
    name: "Darrell Steward",
    companyName: "South market business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
  {
    name: "Darrell Steward",
    companyName: "South market business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
  {
    name: "Darrell Steward",
    companyName: "South market business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
  {
    name: "Darrell Steward",
    companyName: "South market business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
  {
    name: "Darrell Steward",
    companyName: "South market business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
  {
    name: "Darrell Steward",
    companyName: "South market business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
  {
    name: "helllo Steward",
    companyName: "South market business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
  {
    name: "helllo Steward",
    companyName: "South market business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
  {
    name: "helllo Steward",
    companyName: "South market business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
  {
    name: "name Steward",
    companyName: "South market business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
  {
    name: "ehehe Steward",
    companyName: "South market business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
  {
    name: "lolo Steward",
    companyName: "South market business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
  {
    name: "biwi Steward",
    companyName: "South market business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
  {
    name: "helllo Steward",
    companyName: "South market business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
  {
    name: "name Steward",
    companyName: "South market business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
  {
    name: "ehehe Steward",
    companyName: "South market business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
  {
    name: "lolo Steward",
    companyName: "South market business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
  {
    name: "biwi Steward",
    companyName: "South market business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
  {
    name: "ehehe Steward",
    companyName: "South market business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
  {
    name: "lolo Steward",
    companyName: "South market business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
  {
    name: "biwi Steward",
    companyName: "South market business plaza",
    description:
      "From the inital consultation to the final walk through,they demonstrated professionalism, expertise,and a genuine commitment to excellence.",
  },
];
