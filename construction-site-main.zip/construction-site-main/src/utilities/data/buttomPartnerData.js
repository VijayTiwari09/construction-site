
import clip6 from "./../../images/clip6.png";
import clip7 from "./../../images/clip7.png";
import clip8 from "./../../images/clip8.png";

export const Bottomdata = [
  {
    name: "Baba Bhola fuel",
    image: clip6,
  },
  {
    name: "Bns Suppliers",
    image: clip7,
  },
  {
    name: "Bns Transport",
    image: clip8,
  }
];
