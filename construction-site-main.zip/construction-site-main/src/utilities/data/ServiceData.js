import Frame1 from "./../../images/Frame1.png";
import Frame2 from "./../../images/Frame2.png";
import Frame3 from "./../../images/Frame3.png";
import Frame4 from "./../../images/Frame4.png";
import Frame5 from "./../../images/Frame5.png";
// import Frame1 from "./../../../images/Frame1.png"
export const ServiceData = [
  {
    name: "Mining",
    desc:
      "Embracing innovation is at the core of our ethos. We leverage cutting-edge technologies and sustainable practices to drive efficiency, minimize environmental impact.",
    image: Frame1,
    level:"one1"
  },
  {
    name: "Construction",
    desc:
      "client satisfaction is paramount. We prioritize clear communication, transparency, and collaboration to ensure that your vision is brought to life seamlessly.",
    image: Frame2,
    level:"two2"
  },
  {
    name: "Ready mix concrete",
    desc:
      "client satisfaction is paramount. We prioritize clear communication, transparency, and collaboration to ensure that your vision is brought to life seamlessly.",
    image: Frame3,
    level:"three3"
  },
  {
    name: "Transportation",
    desc:
      "client satisfaction is paramount. We prioritize clear communication, transparency, and collaboration to ensure that your vision is brought to life seamlessly.",
    image: Frame4,
    level:"four4"
  },
  {
    name: "Quality service",
    desc:
      "client satisfaction is paramount. We prioritize clear communication, transparency, and collaboration to ensure that your vision is brought to life seamlessly.",
    image: Frame5,
    level:"five5"
  },
];
